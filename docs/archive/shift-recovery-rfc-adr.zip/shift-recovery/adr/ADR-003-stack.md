# ADR-003：TypeScript単一アプリとPostgreSQLを使う

> 2026-09-20継続注記：言語・DBは実装候補のままです。CSV原本の追加を反映した物理モデルは未実装。[RFC-012](../rfc/RFC-012-delivery-and-acceptance.md)で再見積りします。

日付：2026-09-19／状態：設計上の暫定決定、得意言語確認で変更可能  
詳細：[RFC-003](../rfc/RFC-003-implementation.md)

## 背景

1人は画面に強いフルスタック経験者、1人はバックエンド初学者に近い。具体的な言語は未指定。複数リポジトリ・異なる言語の契約管理・分散トランザクションを増やしたくない。

## 決定

Next.jsのUI/APIとTypeScriptのworkerを同じリポジトリに置く。Node.js 24系、PostgreSQL 18系、pgと番号付きSQL migrationを初期案とする。domainをフレームワークから分離する。webとworkerは別プロセスだが、単一ホスト・単一DB・同じリリース単位。

DBにjobs/inbox/outboxを置き、Redis・Temporal・複数エージェント・全面的イベントソーシングを導入しない。画面は2秒ポーリング。

## 選択肢

| 選択肢 | 利点 | 採用しない理由／条件 |
|---|---|---|
| Python API＋別フロント | バックエンドがPythonに習熟していれば早い | 未確認。両名の得意言語次第では変更候補 |
| SQLite | 起動が簡単 | PostgreSQLと同じ競合・排他条件を評価したい |
| 管理DB・serverless中心 | 配布が楽になる可能性 | 接続・契約を増やし、長寿命workerの配置も必要 |
| Next.js＋PostgreSQL | 型を共有、更新保証を明示 | 現在の基準構成として採用 |

## 結果と不利益

DB運用、migration、worker起動は必要。SQL経験が薄い場合はAの負担が増える。技術を一つに揃えれば自動的に短納期になるわけではない。18テーブルの汎用管理画面は作らない。

## 検証・見直し

Day 1に両PCの起動、空DBからseed、API→DB、Orca実接続を確認。既存の得意スタックで大幅に短縮できる場合は変更し、以後このADRをsupersededにする。必要な原子的更新・再起動保証は変更後も維持する。
